﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade3
{
    public partial class Form1 : Form
    {
        double altura, peso, imc;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtImc.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você tem certeza que deseja sair?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
             Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtAltura.Text, out altura) && double.TryParse(txtPeso.Text, out peso))
            {
                imc = peso / Math.Pow(altura,2);
                txtImc.Text = imc.ToString();
            }
            else
                MessageBox.Show("Valores inválidos!");


            if (imc < 18.5)
                MessageBox.Show("Classificação: Magreza");
            else if (imc <= 24.9)
                MessageBox.Show("Classificação: Normal");
            else if (imc <= 29.9)
                MessageBox.Show("Classificação: Sobrepeso");
            else if (imc <= 39.9)
                MessageBox.Show("Classificação: Obesidade");
            else
                MessageBox.Show("Classificação: Obesidade grave");
        }
    }
}
