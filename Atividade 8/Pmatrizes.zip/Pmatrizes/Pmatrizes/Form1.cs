﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;
            for (int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox("Digite números inteiros: ", "Entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }

            Array.Reverse(vetor);

            auxiliar = "";
            auxiliar = string.Join("\n", vetor);
            MessageBox.Show(auxiliar);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            string nomes ="";
            ArrayList lista = new ArrayList() { "Ana", "Thais", "Pedro", "Otávio", "Beatriz", "André", "Camila", "João", "Joana", "Marcelo" };
            lista.Remove("Otávio");

            foreach (string item in lista)
            {
                nomes = nomes + "\n" + item;
            }
            MessageBox.Show(nomes);



        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar;
            for(int i=0; i<20; i++) 
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite números inteiros: ", "Entrada de dados");
                    if (!double.TryParse(auxiliar, out notas[j]))
                    {
                        MessageBox.Show("Número inválido!");
                        j--;
                    }

                }
        }
    }
}
