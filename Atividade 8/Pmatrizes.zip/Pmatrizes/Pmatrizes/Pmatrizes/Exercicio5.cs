﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class Exercicio5 : Form
    {
        public Exercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] respostas = new string[6, 10];
            string[] gabarito= new string[10] { "A", "B", "A", "C", "D", "E", "B", "A", "C", "E" };
            string auxiliar;

            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    respostas[i, j] = Interaction.InputBox("Digite a resposta: ", "Entrada de dados").ToUpper();

                    if(respostas[i, j] == "A" || respostas[i, j] == "B" || respostas[i, j] == "C" || respostas[i, j] == "D" || respostas[i, j] == "E")
                    {

                        if (String.Compare(respostas[i, j], gabarito[j]) == 0)
                        {
                            listBox1.Items.Add($"O aluno {i + 1} acertou, a questão {j + 1} era {gabarito[j]} e escolheu {respostas[i, j]}");
                        }

                        else
                        {
                            listBox1.Items.Add($"O aluno {i + 1} errou, a questão {j + 1} era {gabarito[j]} e escolheu {respostas[i, j]}");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Alterntiva Inválida!");
                        i--;
                    }
                }
            }
        }
    }
}
