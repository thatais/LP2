﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;
using System.Net.Http.Headers;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;
            for (int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox("Digite números inteiros: ", "Entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }

            Array.Reverse(vetor);

            auxiliar = "";
            auxiliar = string.Join("\n", vetor);
            MessageBox.Show(auxiliar);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            string nomes ="";
            ArrayList lista = new ArrayList() { "Ana", "Thais", "Pedro", "Otávio", "Beatriz", "André", "Camila", "João", "Joana", "Marcelo" };
            lista.Remove("Otávio");

            foreach (string item in lista)
            {
                nomes = nomes + "\n" + item;
            }
            MessageBox.Show(nomes);



        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar;
            double mediaAluno=0;
            string medias = "";

            for (int i = 0; i < 20; i++)
            {
 
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do Aluno {i + 1}: ", "Entrada de dados");
                    if (!double.TryParse(auxiliar, out notas[i,j]) || notas[i,j]>10 || notas[i,j] < 0)
                    {
                        MessageBox.Show("Número inválido!");
                        j--;
                    }
                    else  
                    mediaAluno += notas [i,j];
                }
                mediaAluno = mediaAluno / 3;
                medias += $"Aluno {i + 1}: média: {mediaAluno.ToString("N2")}\n";

            }
            MessageBox.Show(medias);
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            Exercicio4 exercicio4 = new Exercicio4();
            exercicio4.Show();
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            Exercicio5 exercicio5 = new Exercicio5();
            exercicio5.Show();
        }
    }
}
