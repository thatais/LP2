﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";

            for (int i = 0; i < vetor.Length; i++) {
                aux = Interaction.InputBox("Digite  Números", "Entrada de Dados");
                 if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido!");
                    i--;

                }
            
            
            }
            Array.Reverse(vetor);
            aux = "";
            aux = string.Join("\n", vetor);
            MessageBox.Show(aux);


        }

        private void button3_Click(object sender, EventArgs e)
        {
            double aux;
            double sum = 0;
            double[,] notas = new double[20, 3];
            double[] medias = new double[20];
            for (int i = 0; i < notas.GetLength(0); i++)
            {
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    if (!double.TryParse(Interaction.InputBox("Digite as Notas", "Entrada de Dados"), out aux))
                    {
                        MessageBox.Show("Entrada inválida");
                        j--;
                        continue;
                    }
                    if(aux >= 0 && aux <= 10)
                    {
                        notas[i, j] = aux;
                        sum += notas[i, j];
                    }
                    else
                    {
                        MessageBox.Show("A nota deve estar entre 0 e 10");
                        j--;
                    }
                }
                medias[i] = sum / 3;
                sum = 0;
            }
            for (int i = 0; i < notas.GetLength(0); i++)
            {
                MessageBox.Show($"Aluno {i + 1}: {medias[i].ToString("F2")}");

            }
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            List<string> lista = new List<string>() { "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thaís" };
            lista.Remove("Otávio");
            string nomes = string.Join("\n", lista);
            MessageBox.Show(nomes);
        
        

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            (new Form5()).Show();
        }

        private void tnExercicio4_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
        }
    }
}
