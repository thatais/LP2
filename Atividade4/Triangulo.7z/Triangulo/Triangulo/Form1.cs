﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Form1 : Form
    {
        double valA, valB, valC;

        public Form1()
        {
            InitializeComponent();
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você tem certeza que deseja sair?", "Saída", MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
                Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValA.Clear();
            txtValB.Clear();
            txtValC.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValA.Text, out valA) || !double.TryParse(txtValB.Text, out valB) || !double.TryParse(txtValC.Text, out valC))
                MessageBox.Show("Valores inválidos!");

            else if (Math.Abs(valB - valC) > valA && valA > valB + valC && Math.Abs(valA - valC) > valB && valB > valA + valC && Math.Abs(valA - valB) > valC && valC > valA + valB)
                MessageBox.Show("Os valores não se encaixam na Regra de formação de triângulo");

            else if (valA == valB && valB == valC)
                MessageBox.Show("O triângulo é EQUILÁTERO");
            else if (valA == valB || valB == valC || valA == valC)
                MessageBox.Show("O triângulo é ISÓSCELES");
            else
                MessageBox.Show("O triângulo é ESCALENO"); 
        }
    }
}
