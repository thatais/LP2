﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pfilme01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] AvalFilmes = new double[3, 2];
            string auxiliar;
            double mediaFilme1 = 0, mediaFilme2 = 0;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota do filme {j + 1} da pessoa {i + 1}: ", "Entrada de dados");
                    if (!double.TryParse(auxiliar, out AvalFilmes[i, j]) || AvalFilmes[i, j] > 10 || AvalFilmes[i, j] < 0)
                    {
                        MessageBox.Show("Valor inválido!");
                        j--;
                    }
                    else
                    {
                        if (j == 0)
                        {
                            mediaFilme1 += AvalFilmes[i, j];
                        }
                        else if (j == 1)
                        {
                            mediaFilme2 += AvalFilmes[i, j];
                        }
                    }
                }
                lstbx.Items.Add($"Pessoa {i + 1} Nota do filme 1: {AvalFilmes[i, 0].ToString("N2")} Nota do filme 2: {AvalFilmes[i, 1].ToString("N2")}");
            }
            mediaFilme1 = mediaFilme1 / 3;
            mediaFilme2 = mediaFilme2 / 3;
            lstbx.Items.Add("...........................................");
            lstbx.Items.Add($"Média filme 1: {mediaFilme1.ToString("N2")}");
            lstbx.Items.Add($"Média filme 2: {mediaFilme2.ToString("N2")}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbx.Items.Clear();
        }
    }
}
